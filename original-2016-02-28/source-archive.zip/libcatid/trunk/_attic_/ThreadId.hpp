// 07/16/09 began

#ifndef CAT_THREAD_ID_HPP
#define CAT_THREAD_ID_HPP

#include <cat/Platform.hpp>

namespace cat {


u32 GetThreadId();


} // namespace cat

#endif // CAT_THREAD_ID_HPP
